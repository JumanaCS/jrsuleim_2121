/**
*changes the circles location and gives a new location
*/
public class MovableCircle implements Movable {
    private final int radius;
    private final MovablePoint center;

    /**
    *creates a moveable circle with the radius and the x,y coordinates
    *@param x the x integer point in (x,y)
    *@param y the y integer point in (x,y)
    *@param radius radius of the circle
    */
    public MovableCircle(int x, int y, int radius) {
        this.radius = radius;
        this.center = new MovablePoint(x, y);
    }

    /**
    *This method moves the points upwards 
    */
    @Override
    public void moveUp() {
        center.moveUp();
    }

    /**
    *This method moves the points down 
    */
    @Override
    public void moveDown() {
        center.moveDown();
    }

    /**
    *This method moves the points left 
    */
    @Override
    public void moveLeft() {
        center.moveLeft();
    }

    /**
    *This method moves the points right 
    */
    @Override
    public void moveRight() {
        center.moveRight();
    }

    /**
    *@return circles location in a string format
    */
    @Override
    public String toString() {
        return "MovableCircle [radius=" + radius + ", center=" + center + "]";
    }

}
