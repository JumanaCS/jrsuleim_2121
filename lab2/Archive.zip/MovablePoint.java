/**
*The class gives the location of the points and changes the location
*/
public class MovablePoint implements Movable {
    int x;
    int y;

    /**
    *This method gives x and y coordinates
    *@param x the x in (x,y)
    *@param y the y in (x,y)
    */
    public MovablePoint(int x, int y) {
        this.x = x;
        this.y = y;
    }

    /**
    *This method makes y coordinates go up by 1 
    */
    @Override
    public void moveUp() {
        y += 1;
    }

    /**
    *This method makes y coordinates go down by 1 
    */
    @Override
    public void moveDown() {
        y -= 1;
    }

    /**
    *This method makes x coordinates go down by 1, moving it to the left by 1 
    */
    @Override
    public void moveLeft() {
        x -= 1;
    }

    /**
    *This method makes x coordinates go up by 1, moving it to the right by 1 
    */
    @Override
    public void moveRight() {
        x += 1;
    }

    /**
    *@return the new location in string format
    */
    @Override
    public String toString() {
        return "MovablePoint [x=" + x + ", y=" + y + "]";
    }
}
