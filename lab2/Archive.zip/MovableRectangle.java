/**
* This class changes the location of the rectangle and gives the new location
*/
public class MovableRectangle implements Movable {
    private final MovablePoint topLeft;
    private final MovablePoint bottomRight;

    /**
    *This method creates a moveable rectangle with the coordinates x1,y1,x2,x2
    *@param x1 the x coordinate of the top left point of the rectangle, the x in (x1,y1)
    *@param y1 the y coordinate of the top left point of the rectangle, the y in (x1,y1)
    *@param x2 the x coordinate of the bottom right point of the rectangle, the x in (x2,y2)
    *@param y2 the y coordinate of the bottom right point of the rectangle, the y in (x2,y2)
    */
    public MovableRectangle(int x1, int y1, int x2, int y2) {
        this.topLeft = new MovablePoint(x1, y1);
        this.bottomRight = new MovablePoint(x2, y2);
    }

    /**
    *This method has the points of the top left and bottom right go up
    */
    @Override
    public void moveUp() {
        topLeft.moveUp();
        bottomRight.moveUp();
    }

    /**
    *This method has the points of the top left and bottom right go down
    */
    @Override
    public void moveDown() {
        topLeft.moveDown();
        bottomRight.moveDown();
    }

    /**
    *This method has the points of the top left and bottom right go left
    */
    @Override
    public void moveLeft() {
        topLeft.moveLeft();
        bottomRight.moveLeft();
    }

    /**
    *This method has the points of the top left and bottom right go right
    */
    @Override
    public void moveRight() {
        topLeft.moveRight();
        bottomRight.moveRight();
    }

    /**
    *@return the rectangles new location in a string format
    */
    @Override
    public String toString() {
        return "MovableRectangle [topLeft=" + topLeft + ", bottomRight=" + bottomRight + "]";
    }
}
