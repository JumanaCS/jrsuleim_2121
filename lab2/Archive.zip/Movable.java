/**
*This is an interface 
*It contains the methods for MoveablePoint, MoveableCircle, and MovebaleRectangle
*It represents the movements
*/
public interface Movable {
    void moveUp();

    void moveDown();

    void moveLeft();

    void moveRight();
}
